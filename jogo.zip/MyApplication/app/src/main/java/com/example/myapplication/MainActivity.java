package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    int inputuser=0;
    int inputpc=0;

    TextView txtcomp= findViewById(R.id.txtpc);


    public void Papel(View view){
        inputuser=1;
        Cpuescolha();
        txtcomp.setText(inputpc);
        Verifica();
    }

    public void Pedra(View view){
        inputuser=2;
        Cpuescolha();
        txtcomp.setText(inputpc);
        Verifica();
    }

    public void Tesoura(View view){
        inputuser=3;
        Cpuescolha();
        txtcomp.setText(inputpc);
        Verifica();
    }


    public void Verifica( ){

        TextView txtwin= findViewById(R.id.txtpc2);

        if(inputpc==inputuser){
            txtwin.setText("Empate!!!!!!");
        }
        else if(inputuser - inputpc == -1 || inputuser - inputpc == 2){
            txtwin.setText("Você Venceu!!!!!!");
        }
        else{
            txtwin.setText("Computador Venceu!!!!!!");
        }
    }


    public void Cpuescolha(){
        Random inputcpu = new Random();
        inputpc=inputcpu.nextInt(3)+1;
    }
}